"""Main module for handling backend related interactions."""
