"""Module for the common code."""
